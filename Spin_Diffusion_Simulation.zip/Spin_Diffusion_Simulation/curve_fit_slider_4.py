# -*- coding: utf-8 -*-
"""
Created on Tue Jul 19 08:33:18 2022

@author: Judge

Peak Grapher and Curve Fit Slider Feature

"""

import csv_to_list
import exact_function
import numpy as np
#from scipy.optimize import curve_fit
#import pylab

import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button

#######################################################################################
#x_data, y_data, del_y_data = [], [], []

def pull_in_data(filename):
    all_plot_points = csv_to_list.load_list(filename)
    csv_to_list.strings_to_numbers(all_plot_points)
    for p in all_plot_points:
        if p[0]=="x": x_data = np.array(p[1:])
        elif p[0]=="y": y_data = np.array(p[1:])
        elif p[0]=="dely": del_y_data = np.array(p[1:])
        elif p[0]=="Legend:": legend = np.array(p[1:])
    return x_data, y_data, del_y_data, legend

def pull_in_vert_data(filename):
    all_plot_points = csv_to_list.load_list(filename)
    csv_to_list.strings_to_numbers(all_plot_points)
    if 'w1' in all_plot_points[0]: p=all_plot_points[0].index('w1')
    if 'w2' in all_plot_points[0]: c=all_plot_points[0].index('w2')
    if 'Height' in all_plot_points[0]: h=all_plot_points[0].index('Height')
    p_data, c_data, h_data = [],[],[]
    for row in all_plot_points[2:10]:
        p_data.append(row[p])
        c_data.append(row[c])
        h_data.append(row[h])
    return p_data, c_data, h_data

def get_peaks_at_ppm(selectedppm, ppmslist):
    threshold=0.25
    ppms, indices = [], []
    for p in range(len(ppmslist)):
        if abs(selectedppm-ppmslist[p])<=threshold:
            ppms.append(ppmslist[p])
            indices.append(p)
    average = sum(ppms)/len(ppms)
    return average, indices


def remember(filename):
    stuff=[]
    all_parameters = csv_to_list.load_list(filename)
    csv_to_list.strings_to_numbers(all_parameters)
    for p in all_parameters:
        pass
    return stuff

#data normalization function - normalizes both the data points and the tolerance values
def normalize_func(ydata):
    normalization = max(ydata)
    norm_ydata = np.array(ydata)/normalization
    return norm_ydata

def normalize_data(ydata):
    normalization = max(ydata)
    norm_ydata = np.array(ydata)/normalization
    return norm_ydata, normalization

#######################################################################################

def func(t, timeshift, diffusion_constant, distance, t1):#t = independent variable, parameters = timeshift, vertstretch, distance, t1
    #parameters = exact_function.spin_diffusion_parameters(distance)
    parameters = exact_function.alt_spin_diffusion_parameters(distance, diffusion_constant)
    spindiffuse = exact_function.spin_value_at((t-timeshift)*abs(t-timeshift), *parameters)
    return spindiffuse*np.exp(-1.0*t/np.exp(t1))

def sumfunc(t, diffusion_constant, parameters):
        # [ [timeshiftA, sigmoidHeightA, distanceA, t1A],
        #   [timeshiftB, sigmoidHeightB, distanceB, t1B],
        #   [timeshiftB, sigmoidHeightB, distanceB, t1B] ]
    values = [ p[1]*normalize_func(func(t, p[0], diffusion_constant, p[2], p[3])) for p in parameters ]
    return sum(values)
    # return SigmoidRatio*normalize_func(func(t, timeshiftA, 1.0, distanceA, t1A)) + (1-SigmoidRatio)*normalize_func(func(t, timeshiftB, 1.0, distanceB, t1B))

#######################################################################################
# # The parametrized function to be plotted
#######################################################################################
diffusion_const = 0.008#water protons, 4.5ppm
# peaks = [13, 14, 15, 16]#water protons, 4.5ppm
#peaks = [6,2,1,5,7]#14.3-27.6ppm diagonals
#peaks = [3]#32.3ppm diagonals
#peaks = [4]#42.3ppm diagonals
peaks = [6,2,1,5,7,8,3,4,9,10,11,12]

#diffusion_const = 0.0025#lipid protons, 3.8, 1.3, 0.9 ppm
# peaks = [1,2,3,4]#lipid protons, 1.2ppm
# peaks = [9,10,11,12]#lipid protons, 0.8ppm/0.9ppm

# Define initial parameters
#######################################################################################
init_parameters = [
    [ init_timeshiftA, init_SigmoidHeightA, init_distanceA, init_t1A ],
    [ init_timeshiftB, init_SigmoidHeightB, init_distanceB, init_t1B ],
    [ init_timeshiftC, init_SigmoidHeightC, init_distanceC, init_t1C ]
    ] = [
        [ 0.0, 0.33, 1.0, 3.6246 ],# 6.15 ],#
        [ 0.0, 0.33, 1.0, 3.6246 ],# 6.15 ],#
        [ 0.0, 0.33, 1.0, 3.6246 ]# 6.15 ]#
        ]
        # [,,,],[,,,],[,,,]]


# #set parameters for peak XXX: H: X.XXXppm C: X.XXXppm
# init_timeshiftA, init_distanceA, init_t1A = , , #
# init_timeshiftB, init_distanceB, init_t1B = , , #
# init_SigmoidRatio = 

# water proton, 4.5ppm: T1~37.5ms, ln(T1) ~ 3.6246
# lipid proton, 0.9ppm: T1~468.87ms, ln(T1) ~ 6.15
# lipid proton, 1.66ppm: T1~288.539ms, ln(T1) ~ 5.66

#######################################################################################
#create the data and function to be plotted

t = np.linspace(0, 20, 1000)
y = sumfunc(t, diffusion_const, init_parameters)
norm_y = normalize_func(y)
# Create the figure and the line that we will manipulate
fig, ax = plt.subplots()

line, = plt.plot(t,
                 normalize_func(sumfunc(t, diffusion_const, init_parameters)),
                 lw=3)
#code for multiple, unlimited sigmoids
#lineS, = 


lineA, = plt.plot(t,
                  init_SigmoidHeightA*normalize_func(func(t,
                                      init_timeshiftA,
                                      diffusion_const,
                                      init_distanceA, init_t1A)),
                  lw=1
                  )
lineB, = plt.plot(t,
                  init_SigmoidHeightB*normalize_func(func(t,
                                      init_timeshiftB,
                                      diffusion_const,
                                      init_distanceB, init_t1B)),
                  lw=1
                  )
lineC, = plt.plot(t,
                  init_SigmoidHeightC*normalize_func(func(t,
                                      init_timeshiftC,
                                      diffusion_const,
                                      init_distanceC, init_t1C)),
                  lw=1
                  )

#folder = "C:/Users/Judge/Documents/Research/ABeta/Proton Distance Experiment/Spin Diffusion Build-Up Data/"
#folder = "C:/Users/Judge/Documents/Research/ABeta/Proton Distance Experiment/Short-Mixing-Matching/Build-Up Peaks/"
folder = "C:/Users/Judge/Documents/Research/ABeta/Proton Distance Experiment/Re-Done Re-Done Spin Diffusion Measurements/"

peaks = [4,81,144,200]
for n in peaks:#range(14,15,1):
    #peakfile = "peak"+str(n)+".csv"
    peakfile = "hetcor2DHC_thmix_"+str(n)+"ms_tau_1.25ms.csv"
    #xdata, ydata, delydata, legend = pull_in_data(folder+peakfile)
    h_data, c_data, height_data = pull_in_vert_data(folder+peakfile)
    
    n = min(len(xdata), len(ydata), len(delydata))
    ns = [i for i in range(n) if not(xdata[i]=='' or ydata[i]=='' or delydata[i]=='') ]
    xdata = [float(xdata[i]) for i in ns]
    ydata = [float(ydata[i]) for i in ns]
    delydata = [float(delydata[i]) for i in ns]
    root_xdata = list(np.power(np.array(xdata), 0.5))
    
    pre_norm_ydata = [ydata[i]/delydata[i] for i in ns]#ADDED TO NORMALIZE WRT SIGNAL NOISE
    pre_norm_delydata = [delydata[i]/delydata[i] for i in ns]#ADDED TO NORMALIZE WRT SIGNAL NOISE
    
    norm_ydata, norm_constant = normalize_data(pre_norm_ydata)
    norm_delydata = list(np.array(pre_norm_delydata)/norm_constant)
    
    plt.errorbar(root_xdata, norm_ydata,
                  marker=".", markerfacecolor="black", #markeredgecolor="red",
                  yerr=norm_delydata, capsize=3,
                  label=' '.join(legend) )

ax.set_xlabel('sqrt(Time) [(ms)^0.5]')
ax.legend()
# adjust the main plot to make room for the sliders
plt.subplots_adjust(left=0.5, bottom=0.25)

# ax.plot([1, 2, 3], label='Inline label')
# ax.legend()

####################################################################
# Sliders of Sigmoid A - timeshiftA, distanceA, t1A
####################################################################
axtimeshiftA = plt.axes([0.03, 0.25, 0.03, 0.65])
timeshiftA_slider = Slider(
    ax=axtimeshiftA,
    label='Delay A',
    valmin=-5.0,
    valmax=19.99,
    valinit=init_timeshiftA,
    orientation="vertical"
)
axSigmoidHeightA = plt.axes([0.06, 0.22, 0.03, 0.65])
vertstretchA_slider = Slider(
    ax=axSigmoidHeightA,
    label='A Height',
    valmin=0.0,
    valmax=1.0,
    valinit=init_SigmoidHeightA,
    orientation="vertical"
)
axdistanceA = plt.axes([0.09, 0.19, 0.03, 0.65])
distanceA_slider = Slider(
    ax=axdistanceA,
    label='Distance A',
    valmin=0.01,
    valmax=1.0,
    valinit=init_distanceA,
    orientation="vertical"
)
axt1A = plt.axes([0.12, 0.16, 0.03, 0.65])
t1A_slider = Slider(
    ax=axt1A,
    label='ln(T1 A)',
    valmin=0.01,
    valmax=10.0,
    valinit=init_t1A,
    orientation="vertical"
)
####################################################################
# Sliders of Sigmoid B - timeshiftB, distanceB, t1B
####################################################################
axtimeshiftB = plt.axes([0.18, 0.25, 0.03, 0.65])
timeshiftB_slider = Slider(
    ax=axtimeshiftB,
    label='Delay B',
    valmin=-5.0,
    valmax=19.99,
    valinit=init_timeshiftB,
    orientation="vertical"
)
axSigmoidHeightB = plt.axes([0.21, 0.22, 0.03, 0.65])
vertstretchB_slider = Slider(
    ax=axSigmoidHeightB,
    label='B Height',
    valmin=0.0,
    valmax=1.0,
    valinit=init_SigmoidHeightB,
    orientation="vertical"
)
axdistanceB = plt.axes([0.24, 0.19, 0.03, 0.65])
distanceB_slider = Slider(
    ax=axdistanceB,
    label='Distance B',
    valmin=0.01,
    valmax=1.0,
    valinit=init_distanceB,
    orientation="vertical"
)
axt1B = plt.axes([0.27, 0.16, 0.03, 0.65])
t1B_slider = Slider(
    ax=axt1B,
    label='ln(T1 B)',
    valmin=0.01,
    valmax=10.0,
    valinit=init_t1B,
    orientation="vertical"
)
####################################################################
# Sliders of Sigmoid B - timeshiftB, distanceB, t1B
####################################################################
axtimeshiftC = plt.axes([0.33, 0.25, 0.03, 0.65])
timeshiftC_slider = Slider(
    ax=axtimeshiftC,
    label='Delay C',
    valmin=-5.0,
    valmax=19.99,
    valinit=init_timeshiftC,
    orientation="vertical"
)
axSigmoidHeightC = plt.axes([0.36, 0.22, 0.03, 0.65])
vertstretchC_slider = Slider(
    ax=axSigmoidHeightC,
    label='C Height',
    valmin=0.0,
    valmax=1.0,
    valinit=init_SigmoidHeightC,
    orientation="vertical"
)
axdistanceC = plt.axes([0.39, 0.19, 0.03, 0.65])
distanceC_slider = Slider(
    ax=axdistanceC,
    label='Distance C',
    valmin=0.01,
    valmax=1.0,
    valinit=init_distanceC,
    orientation="vertical"
)
axt1C = plt.axes([0.42, 0.16, 0.03, 0.65])
t1C_slider = Slider(
    ax=axt1C,
    label='ln(T1 C)',
    valmin=0.01,
    valmax=10.0,
    valinit=init_t1C,
    orientation="vertical"
)

# The function to be called anytime a slider's value changes
def update(val):
    global diffusion_const
    line.set_ydata(normalize_func(sumfunc(t, diffusion_const, [
        [timeshiftA_slider.val, vertstretchA_slider.val, distanceA_slider.val, t1A_slider.val],
        [timeshiftB_slider.val, vertstretchB_slider.val, distanceB_slider.val, t1B_slider.val],
        [timeshiftC_slider.val, vertstretchC_slider.val, distanceC_slider.val, t1C_slider.val]
        ])))
    
    lineA.set_ydata(vertstretchA_slider.val*normalize_func(func(t,
                        timeshiftA_slider.val, diffusion_const, distanceA_slider.val, t1A_slider.val)))
    
    lineB.set_ydata(vertstretchB_slider.val*normalize_func(func(t,
                        timeshiftB_slider.val, diffusion_const, distanceB_slider.val, t1B_slider.val)))
    
    lineC.set_ydata(vertstretchC_slider.val*normalize_func(func(t,
                        timeshiftC_slider.val, diffusion_const, distanceC_slider.val, t1C_slider.val)))
    
    fig.canvas.draw_idle()

# register the update function with each slider
timeshiftA_slider.on_changed(update)
vertstretchA_slider.on_changed(update)
distanceA_slider.on_changed(update)
t1A_slider.on_changed(update)

timeshiftB_slider.on_changed(update)
vertstretchB_slider.on_changed(update)
distanceB_slider.on_changed(update)
t1B_slider.on_changed(update)

timeshiftC_slider.on_changed(update)
vertstretchC_slider.on_changed(update)
distanceC_slider.on_changed(update)
t1C_slider.on_changed(update)

# Create a `matplotlib.widgets.Button` to reset the sliders to initial values.
resetax = plt.axes([0.8, 0.025, 0.1, 0.04])
button = Button(resetax, 'Reset', hovercolor='0.975')

def reset(event):
    timeshiftA_slider.reset()
    distanceA_slider.reset()
    t1A_slider.reset()
    vertstretchA_slider.reset()
    
    timeshiftB_slider.reset()
    distanceB_slider.reset()
    t1B_slider.reset()
    vertstretchB_slider.reset()
    
    timeshiftC_slider.reset()
    distanceC_slider.reset()
    t1C_slider.reset()
    vertstretchC_slider.reset()

button.on_clicked(reset)

plt.show()
