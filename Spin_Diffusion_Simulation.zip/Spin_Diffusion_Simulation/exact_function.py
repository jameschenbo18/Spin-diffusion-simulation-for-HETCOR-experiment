#from sympy import *
import sympy as sp
import numpy as np
import math

protein_distance = 0.2#distance in nm

#DiffX in nm^2/ms, aX in nm
#OmegaX in ms^-1
DiffL, aL = 0.012, 0.2
OmegaL = OL = DiffL/(aL*aL)#lipid
DiffC, aC = 0.0025, protein_distance*1.0
OmegaC = OC = DiffC/(aC*aC)#countour
DiffP, aP = 0.3, 0.2
OmegaP = OP = DiffP/(aP*aP)#peptide

def spin_diffusion_parameters(distance):
    global DiffC, OP
    a = DiffC/(distance**2)
    b = OP*1.0
    g = math.sqrt((a+b)**2 - 3*a*b)

    M = sp.Matrix([[1.0, 1.0, 1.0, 1.0],
                [1.0, (g-b)/a, (-b-g)/a, 0.0],
                [1.0, b*(b-g)/(a*(a-g)), b*(b+g)/(a*(a+g)), 0.0]])
    M_rref, pivots = M.rref()
    c1 = float(M_rref[0,3])
    c2 = float(M_rref[1,3])
    c3 = float(M_rref[2,3])
    k2 = c2*(g-b)/a
    k3 = c3*(-b-g)/a
    l2 = -1.0*(a+b-g)
    l3 = -1.0*(a+b+g)
    return c1, k2, l2, k3, l3
#z,x,v,n,m = lattice_relaxation_parameters(protein_distance)

def alt_spin_diffusion_parameters(distance, DiffC):
    global OP
    a = DiffC/(distance**2)
    b = OP*1.0
    g = math.sqrt((a+b)**2 - 3*a*b)

    M = sp.Matrix([[1.0, 1.0, 1.0, 1.0],
                [1.0, (g-b)/a, (-b-g)/a, 0.0],
                [1.0, b*(b-g)/(a*(a-g)), b*(b+g)/(a*(a+g)), 0.0]])
    M_rref, pivots = M.rref()
    c1 = float(M_rref[0,3])
    c2 = float(M_rref[1,3])
    c3 = float(M_rref[2,3])
    k2 = c2*(g-b)/a
    k3 = c3*(-b-g)/a
    l2 = -1.0*(a+b-g)
    l3 = -1.0*(a+b+g)
    return c1, k2, l2, k3, l3


def spin_value_at(t, c1, k2, l2, k3, l3):
    if type(t)==type(np.linspace(0,1,2)):
        f = [c1 + k2*np.exp(l2*i) + k3*np.exp(l3*i) if i>0.0 else 0.0 for i in t]
        return np.array(f)
        # return c1 + k2*np.exp(l2*t) + k3*np.exp(l3*t)
    else:
        if (t>0.0):
            return c1 + k2*np.exp(l2*t) + k3*np.exp(l3*t)
        else:
            return 0.0
