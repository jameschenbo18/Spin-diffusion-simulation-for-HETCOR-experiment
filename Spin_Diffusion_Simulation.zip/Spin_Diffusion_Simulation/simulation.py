import matplotlib.pyplot as plt
import math

protein_distance = 0.2#distance in nm

#DiffX in nm^2/ms, aX in nm
#OmegaX in ms^-1
DiffL, aL = 0.012, 0.2
OmegaL = OL = DiffL/(aL*aL)
DiffC, aC = 0.0025, protein_distance*1.0
OmegaC = OC = DiffC/(aC*aC)
DiffP, aP = 0.25, 0.2
OmegaP = OP = DiffP/(aP*aP)

def simulate(lattice_spot, aC, totaltime, timestep):
    global DiffC, OP, OL
    OC = DiffC/(aC*aC)
    #print("OmegaC:", OC)

    lattice_initial = [1.0,0.0,0.0]#[ Lipid, Peptide, Peptide ]
    lattices = [ [ 0.0 for la in lattice_initial ] for t in range(int(totaltime/timestep))]
    lot = [ lattice_initial ] + lattices #lattice_over_time
    
    for t in range(len(lattices)):
        lot[t+1][1] = lot[t][1] + ts*( lot[t][0]*OC + lot[t][2]*OP - lot[t][1]*(OC+OP) )#m_i
        lot[t+1][0] = lot[t][0] + ts*( lot[t][1]*OC - lot[t][0]*(OC) )#m_i-1
        lot[t+1][2] = lot[t][2] + ts*OP*( lot[t][1] - lot[t][2] )#m_i+1

    times = [ timestep*n for n in range(len(lot)) ]
    values = [ lat[lattice_spot] for lat in lot ]
    return times, values, max(values)

#time in milliseconds
timestep = ts = 0.001
totaltime = 100.0
proton_distances = [0.005, 0.010, 0.015, 0.020]
def graph_sample():
    global totaltime, ts, proton_distances
    print("OmegaL:", OmegaL)
    print("OmegaP:", OmegaP)

    #set up graphs
    color=[0,0,1]
    fig, plots = plt.subplots(len(proton_distances),1)
    fig.subplots_adjust(hspace=1.0)
    fig.subplots_adjust(wspace=2.0)

    lats_over_time = [[] for p in proton_distances]
    for p in range(len(proton_distances)):
        print("")
        print("Simulation", p, "start.")
        times, lats_over_time[p], normalization = simulate(1, proton_distances[p]*1.0, totaltime, timestep)
        print("Simulation", p, "complete.")

        #plot graph p
        plots[p].set_title("lipid-peptide proton distance: "+str(proton_distances[p])+" nm")
        plots[p].set_xlabel("sqrt(tau) in sqrt(ms)")
        plots[p].set_ylabel("Intensity")
        plots[p].set_xlim(-0.1, math.sqrt(totaltime)+0.1)
        plots[p].set_ylim(0.0, normalization*1.1)
        plots[p].plot([math.sqrt(t) for t in times], lats_over_time[p], c=color)

        print("Simulation", p, "plotted.")
    #plt.tight_layout(pad=1)
    fig.canvas.draw()

    fig.set_figheight(2.0*len(proton_distances))
    fig.set_figwidth(7)
    plt.show()

#graph_sample()
